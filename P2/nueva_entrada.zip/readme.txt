YEEE
el descarga.png es la foto que carga por defecto
tienes que meter esta carpeta en el xampp para probarla
funciona con la base de datos del profe, asique es posible que 
tengas que cambiar la configuracion de la carpeta rest
aunque es probable que te tire. GOOOD LUCK MY FRIEND!