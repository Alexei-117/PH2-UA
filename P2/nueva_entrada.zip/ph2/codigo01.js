function hacerLogin(frm){
	let xhr = new XMLHttpRequest(), 
		url = 'http://localhost/ph2/rest/login/',
		fd	= new FormData(frm);

	xhr.open('POST', url, true);
	xhr.onload = function(){
		console.log(xhr.responseText);
		let v = JSON.parse(xhr.responseText);
		if(v.RESULTADO == 'ok'){
			sessionStorage['du'] = xhr.responseText;
		}
		else{

		}
		frm.parentNode.querySelector('p').innerHTML = xhr.responseText;
	};
	xhr.send(fd);

	return false;
}
function mostrarFoto(inp){
	let fr = new FileReader();

	fr.onload = function(){
		inp.parentNode.querySelector('img').src = fr.result;
		inp.parentNode.querySelector('img').alt = inp.files[0].name;
	};
	fr.readAsDataURL(inp.files[0]);
}
function enviarFoto(btn){
	let xhr = new XMLHttpRequest(),
		url = 'http://localhost/ph2/rest/foto/',
		fd  = new FormData(),
		du  = JSON.parse(sessionStorage['du']);

	fd.append('login', du.login);
	fd.append('id_entrada',1);
	fd.append('texto', btn.parentNode.querySelector('textarea').value);
	fd.append('foto', btn.parentNode.querySelector('[type="file"]').files[0]);

	xhr.open('POST', url, true);
	xhr.onload = function(){
		console.log(xhr.responseText);
	};

	xhr.sendRequestHeader('Authorization', du.clave);
	xhr.send(fd);
}